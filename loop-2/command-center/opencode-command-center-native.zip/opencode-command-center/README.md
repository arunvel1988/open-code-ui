# OpenCode Command Center — Native Ubuntu Edition

This edition runs directly on the Ubuntu host. **OpenCode is installed in the Ubuntu user's home directory** at `~/.opencode/bin/opencode`. The Flask dashboard runs as a native Python virtualenv process managed by the user's systemd service.

There is no Dockerfile, Docker Compose, container, or Docker volume in this edition.

## 1. Extract and install (as your normal Ubuntu user)

```bash
unzip opencode-command-center-native.zip
cd opencode-command-center
cp .env.example .env
nano .env
```

Set a strong `DASHBOARD_PASSWORD` and generate `FLASK_SECRET_KEY` with `openssl rand -hex 32`. Keep `BIND_IP=127.0.0.1` unless you have separately secured the dashboard.

Install prerequisites if needed:

```bash
sudo apt-get update
sudo apt-get install -y curl python3 python3-venv python3-pip
```

Run the installer **without sudo**:

```bash
bash install.sh
```

The script installs OpenCode for the current Ubuntu user, creates a Python virtual environment, installs the dashboard dependencies, and creates/enables a user-level systemd service. It does not run Docker.

## 2. Open the dashboard

On the VM: `http://127.0.0.1:5000`

From your laptop, use an SSH tunnel:

```bash
ssh -L 5000:127.0.0.1:5000 <ubuntu-user>@<VM-IP>
```

Then open `http://127.0.0.1:5000` locally. Sign in with the dashboard password from `.env`.

## 3. OpenCode host installation

The OpenCode executable is installed at:

```bash
$HOME/.opencode/bin/opencode
```

Check it directly from Ubuntu:

```bash
$HOME/.opencode/bin/opencode --version
which opencode  # may require adding ~/.opencode/bin to PATH
```

The dashboard's Install action also invokes the official installer with the dashboard's Ubuntu user's `HOME`; it does not create a container. The dashboard starts `opencode serve` as a child process on `127.0.0.1:4096`.

## 4. Service management

```bash
systemctl --user status opencode-command-center
systemctl --user restart opencode-command-center
systemctl --user stop opencode-command-center
journalctl --user -u opencode-command-center -f
```

To keep the user service running after logout/reboot, enable lingering (optional):

```bash
sudo loginctl enable-linger "$USER"
```

## 5. Projects and data

Default project directory: `~/projects` (on the Ubuntu host). Change it in Dashboard Settings. Dashboard settings and logs are stored in `data/` under this project. OpenCode config and authentication remain in the normal Ubuntu user home (`~/.config/opencode` and `~/.local/share/opencode`, as used by OpenCode). Back up these locations and protect `.env` and `data/settings.json`.

## Security

Keep the dashboard bound to localhost and access it over SSH tunnelling. Do not expose it directly to the public internet without HTTPS, firewall restrictions, and additional security review. The dashboard can run prompts that modify project files; use Git checkpoints.
